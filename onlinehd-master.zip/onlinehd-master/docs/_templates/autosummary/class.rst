{{ fullname | escape | underline}}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :members:
   :special-members:
   :inherited-members:
   :show-inheritance:
   :exclude-members: __weakref__, __init__
